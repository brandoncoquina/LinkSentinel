<?php
/**
 * Plugin Name:       LinkSentinel
 * Description:       Scan internal links for redirects & breakage. Auto‑fix 301/308 permanently redirected links; queue 302/307 and broken links for review. Includes a dashboard with progress indicators, last scan metadata and a CSV export for resolved links.
 * Version:           1.8.8
 * Author:            Coquina Works
 * Author URI:        https://www.coquinaworks.com
 * License:           GPL‑2.0‑or‑later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       link-sentinel
 * Domain Path:       /languages
 */

/*
 * Main bootstrap file for the LinkSentinel plugin.
 *
 * This file sets up plugin defaults, registers hooks and loads the
 * administrative interface.  It is intentionally lean and avoids
 * hard‑coding any environment‑specific configuration.  When introducing
 * new functionality, ensure that the core free features remain intact
 * and that any premium extensions are gated behind capability checks or
 * license keys.
 */

defined( 'ABSPATH' ) || die( 'No direct access allowed.' );

// Define a version constant for internal use.  This value should match the
// version header above and must be updated on each release.
if ( ! defined( 'RFX_VERSION' ) ) {
    /**
     * Internal version constant.  This should mirror the plugin header
     * version above and be updated with each release.  Incrementing
     * this value also busts browser caches for our enqueued assets.
     */
    define( 'RFX_VERSION', '1.8.8' );
}

/**
 * Load the plugin text domain for localization.
 *
 * The text domain is loaded on the `plugins_loaded` hook to ensure that
 * translations are available throughout both the admin and public facing
 * portions of the plugin.  Strings throughout the plugin should use
 * functions such as __( 'string', 'link-sentinel' ) to allow translators
 * to provide localized versions.
 */
function linksentinel_load_textdomain() {
    load_plugin_textdomain( 'link-sentinel', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'linksentinel_load_textdomain' );

/**
 * Conditionally load the bundled Action Scheduler library.
 *
 * Action Scheduler is used to queue background jobs so that link scanning can
 * operate asynchronously without blocking a page load.  If a host already
 * provides Action Scheduler (via WooCommerce or a different plugin) then the
 * functions will already exist and loading a second copy could create
 * conflicts.  This helper checks for the existence of `as_enqueue_async_action`
 * before including our vendored copy.
 */
function rfx_load_action_scheduler() {
    if ( function_exists( 'as_enqueue_async_action' ) ) {
        return;
    }
    $lib = plugin_dir_path( __FILE__ ) . 'lib/action-scheduler/action-scheduler.php';
    if ( file_exists( $lib ) ) {
        require_once $lib;
    }
}

/**
 * Activation hook: create database table and schedule daily scan.
 */
function linksentinel_activate() {
    rfx_load_action_scheduler();

    global $wpdb;
    $table_name      = $wpdb->prefix . 'rfx_link_monitor';
    $charset_collate = $wpdb->get_charset_collate();
    $sql             = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        post_id bigint(20) NOT NULL,
        original_url text NOT NULL,
        final_url text,
        http_status int(11) DEFAULT NULL,
        status_message varchar(191) DEFAULT NULL,
        resolution_status varchar(20) NOT NULL DEFAULT 'pending',
        scan_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resolution_date datetime DEFAULT NULL,
        PRIMARY KEY  (id),
        KEY post_id (post_id),
        KEY http_status (http_status),
        KEY resolution_status (resolution_status)
    ) $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );

    // Default settings if none exist.
    $settings = get_option( 'rfx_settings', null );
    if ( null === $settings ) {
        // Default scan at 2:00 AM and post/page types.
        $settings = [
            'scan_hour'   => 2,
            'scan_minute' => 0,
            'post_types'  => [ 'post', 'page' ],
        ];
        update_option( 'rfx_settings', $settings );
    }

    // Schedule the nightly scan according to settings.
    rfx_schedule_daily_scan();
}
register_activation_hook( __FILE__, 'linksentinel_activate' );

/**
 * Deactivation hook: clear scheduled events.
 */
function linksentinel_deactivate() {
    wp_clear_scheduled_hook( 'rfx_nightly_scan' );
}
register_deactivation_hook( __FILE__, 'linksentinel_deactivate' );

/**
 * Schedule the nightly scan event based on user settings.
 *
 * Reads the `rfx_settings` option for `scan_hour` and `scan_minute` and
 * schedules the `rfx_nightly_scan` event accordingly.  If an event is
 * already scheduled, it is cleared first to avoid duplicate events.  If
 * the scheduled time has already passed for today, the event is
 * scheduled for the following day.  Uses the site timezone.
 */
function rfx_schedule_daily_scan() {
    // Remove any existing scheduled hooks.
    wp_clear_scheduled_hook( 'rfx_nightly_scan' );
    $settings    = get_option( 'rfx_settings', [] );
    $hour        = isset( $settings['scan_hour'] ) ? intval( $settings['scan_hour'] ) : 2;
    $minute      = isset( $settings['scan_minute'] ) ? intval( $settings['scan_minute'] ) : 0;
    // Build a timestamp for today at the scheduled time in the site timezone.
    $timestamp   = strtotime( date( 'Y-m-d ' . sprintf( '%02d:%02d:00', $hour, $minute ), current_time( 'timestamp' ) ) );
    // If the scheduled time is in the past, schedule for the next day.
    if ( $timestamp <= current_time( 'timestamp' ) ) {
        $timestamp = strtotime( '+1 day', $timestamp );
    }
    // Schedule the event daily.
    wp_schedule_event( $timestamp, 'daily', 'rfx_nightly_scan' );
}

/**
 * Uninstall hook: remove plugin options but leave logs intact.
 *
 * The uninstall file is separate but if needed you can call this function
 * manually when deleting the plugin.  We intentionally leave the link
 * monitor table to allow users to keep historical data even after
 * deactivating the plugin.
 */
function linksentinel_uninstall() {
    delete_option( 'rfx_scan_last_started' );
    delete_option( 'rfx_scan_last_type' );
    delete_option( 'rfx_settings' );
}

/**
 * Admin asset loader.  Only loads on our plugin screen to avoid polluting
 * unrelated admin pages.
 */
function rfx_admin_enqueue_scripts( $hook ) {
    // Tools screens have hooks like tools_page_link-sentinel.
    if ( strpos( $hook, 'link-sentinel' ) === false ) {
        return;
    }

    /*
     * Use set_url_scheme() to ensure that our asset URLs match the scheme (HTTP or HTTPS) of the current request.
     * Without this, browsers running in HTTPS‑only mode may refuse to load http assets, causing console warnings.
     */
    $base_url = plugin_dir_url( __FILE__ );
    $scheme   = is_ssl() ? 'https' : 'http';
    $base_url = set_url_scheme( $base_url, $scheme );
    wp_enqueue_script( 'linksentinel-admin', $base_url . 'assets/js/admin-main.js', [ 'jquery' ], RFX_VERSION, true );
    wp_localize_script( 'linksentinel-admin', 'RFXAdmin', [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'rfx_start_scan_nonce' ),
    ] );
    wp_enqueue_style( 'linksentinel-admin',  $base_url . 'assets/css/admin.css', [], RFX_VERSION );
}
add_action( 'admin_enqueue_scripts', 'rfx_admin_enqueue_scripts' );

/**
 * Helper to determine if a URL is internal (same domain or a relative path).
 *
 * External links—especially in the context of premium scanning—could be
 * optionally processed in the future, but the free version scans only
 * internal links.  Relative paths like `/sample-page/` are treated as
 * internal by default.
 *
 * @param string $url The URL to examine.
 * @return bool True if internal, false otherwise.
 */
function rfx_is_internal_link( $url ) {
    if ( empty( $url ) ) {
        return false;
    }
    // Check for absolute URLs starting with http(s).
    if ( 0 === strpos( $url, 'http://' ) || 0 === strpos( $url, 'https://' ) ) {
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
        $link_host = wp_parse_url( $url, PHP_URL_HOST );
        return ! empty( $link_host ) && $site_host === $link_host;
    }
    // Relative paths starting with '/' are considered internal.
    return '/' === $url[0];
}

/**
 * Find the final destination of a URL without blindly following all redirects.
 *
 * We manually follow redirects up to a maximum of 5 hops, capturing the
 * first hop status code to determine whether the redirect is permanent
 * (301/308) or temporary (302/307).  This allows us to auto‑fix content
 * only when a permanent redirect is detected.  Requests are attempted via
 * `wp_remote_head()` first to minimize download size and fall back to
 * `wp_remote_get()` if necessary.  The user agent identifies the plugin
 * name/version.
 *
 * @param string $url The original URL.
 * @return array|false Array with keys: final_url, status_code,
 *                     status_message, first_hop_code, is_permanent.
 */
function rfx_get_final_destination_url( $url ) {
    $max_hops       = 5;
    $current        = $url;
    $current_abs    = ( 0 === strpos( $current, 'http://' ) || 0 === strpos( $current, 'https://' ) ) ? $current : home_url( $current );
    $first_hop_code = null;
    $status_message = '';
    $final_url_abs  = $current_abs;
    $status_code    = 0;

    for ( $i = 0; $i < $max_hops; $i++ ) {
        $resp = wp_remote_head( $current_abs, [
            'redirection' => 0,
            'timeout'     => 10,
            'headers'     => [ 'User-Agent' => 'WordPress/LinkSentinel/' . RFX_VERSION ],
        ] );
        if ( is_wp_error( $resp ) ) {
            $resp = wp_remote_get( $current_abs, [
                'redirection' => 0,
                'timeout'     => 10,
                'headers'     => [ 'User-Agent' => 'WordPress/LinkSentinel/' . RFX_VERSION ],
            ] );
            if ( is_wp_error( $resp ) ) {
                return false;
            }
        }
        $code          = intval( wp_remote_retrieve_response_code( $resp ) );
        $status_message = wp_remote_retrieve_response_message( $resp );
        if ( null === $first_hop_code ) {
            $first_hop_code = $code;
        }
        // Handle redirects manually.
        if ( $code >= 300 && $code < 400 ) {
            $loc = wp_remote_retrieve_header( $resp, 'location' );
            if ( empty( $loc ) ) {
                $status_code   = $code;
                $final_url_abs = $current_abs;
                break;
            }
            // Resolve relative redirects against the current URL's host.
            if ( 0 !== strpos( $loc, 'http://' ) && 0 !== strpos( $loc, 'https://' ) ) {
                $parsed = wp_parse_url( $current_abs );
                $prefix = $parsed['scheme'] . '://' . $parsed['host'] . ( isset( $parsed['port'] ) ? ':' . $parsed['port'] : '' );
                if ( 0 === strpos( $loc, '/' ) ) {
                    $current_abs = $prefix . $loc;
                } else {
                    $base        = trailingslashit( dirname( $parsed['path'] ) );
                    $current_abs = $prefix . '/' . ltrim( $base . $loc, '/' );
                }
            } else {
                $current_abs = $loc;
            }
            continue;
        }
        // Non‑redirect response.
        $status_code   = $code;
        $final_url_abs = $current_abs;
        break;
    }
    // Convert final absolute URL back to a relative URL for internal links.
    $final_url = $final_url_abs;
    if ( rfx_is_internal_link( $final_url_abs ) ) {
        $final_url = wp_make_link_relative( $final_url_abs );
    }
    $is_permanent = in_array( intval( $first_hop_code ), [ 301, 308 ], true );
    return [
        'final_url'      => esc_url_raw( $final_url ),
        'status_code'    => $status_code,
        'status_message' => $status_message,
        'first_hop_code' => $first_hop_code,
        'is_permanent'   => $is_permanent,
    ];
}

/**
 * Log a link issue to the database.
 *
 * @param int    $post_id          The post ID containing the link.
 * @param string $original_url      The original URL found in content.
 * @param string $final_url         The final resolved URL (optional).
 * @param int    $http_status       HTTP status code from the request.
 * @param string $status_message    Human‑readable status message.
 * @param string $resolution_status Either 'pending' or 'resolved'.
 */
function rfx_log_link_issue( $post_id, $original_url, $final_url, $http_status, $status_message, $resolution_status = 'pending' ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfx_link_monitor';
    $wpdb->insert(
        $table_name,
        [
            'post_id'           => absint( $post_id ),
            'original_url'      => $original_url,
            'final_url'         => $final_url,
            'http_status'       => (int) $http_status,
            'status_message'    => $status_message,
            'resolution_status' => $resolution_status,
            'scan_date'         => current_time( 'mysql' ),
            'resolution_date'   => ( 'resolved' === $resolution_status ? current_time( 'mysql' ) : null ),
        ],
        [ '%d', '%s', '%s', '%d', '%s', '%s', '%s' ]
    );
}

/**
 * Retrieve the list of post IDs to scan.
 *
 * Uses plugin settings stored in the `rfx_settings` option to determine
 * which post types to scan.  Defaults to posts and pages.  Only
 * published posts are scanned.
 *
 * @return int[] Array of post IDs.
 */
function rfx_get_scannable_post_ids() {
    global $wpdb;
    $settings   = get_option( 'rfx_settings', [] );
    $post_types = ( ! empty( $settings['post_types'] ) && is_array( $settings['post_types'] ) )
        ? array_map( 'sanitize_text_field', $settings['post_types'] )
        : [ 'post', 'page' ];
    $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
    $sql = "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($placeholders)";
    return $wpdb->get_col( $wpdb->prepare( $sql, $post_types ) );
}

/**
 * Process a single post: find internal links, resolve them and log issues.
 *
 * This function uses a simple regex to extract the `href` attribute from
 * anchor tags.  Each unique internal link is resolved via
 * `rfx_get_final_destination_url()`.  If a permanent redirect is detected
 * (first hop code 301 or 308) the content is updated to point to the final
 * URL and the issue is logged as resolved.  Temporary redirects and
 * broken links are logged as pending for manual review.
 *
 * @param int $post_id Post ID to scan.
 */
function rfx_process_single_post( $post_id ) {
    $post = get_post( $post_id );
    if ( ! $post || empty( $post->post_content ) ) {
        return;
    }
    $content        = $post->post_content;
    $updated_content = $content;
    // Match href attributes in anchor tags.
    $pattern = '/<a\s+(?:[^>]*?\s+)?href="([^"]*)"/i';
    if ( preg_match_all( $pattern, $content, $matches ) ) {
        $links_found = array_unique( $matches[1] );
        // Fetch auto-resolve setting once per post.  This determines whether
        // permanent redirects should be automatically updated or flagged
        // for review.  Defaults to disabled when not set.
        $settings     = get_option( 'rfx_settings', [] );
        $auto_resolve = ( isset( $settings['auto_resolve_permanent'] ) && $settings['auto_resolve_permanent'] );

        foreach ( $links_found as $url ) {
            if ( empty( $url ) || 0 === strpos( $url, '#' ) || ! rfx_is_internal_link( $url ) ) {
                continue;
            }
            // Skip admin/login URLs. We only care about links within posts, pages and media.
            $parsed_path = wp_parse_url( $url, PHP_URL_PATH );
            if ( is_string( $parsed_path ) ) {
                // Normalize to leading slash for relative URLs.
                if ( isset( $parsed_path[0] ) && $parsed_path[0] !== '/' ) {
                    $parsed_path = '/' . $parsed_path;
                }
                if ( 0 === strpos( $parsed_path, '/wp-admin' ) || 0 === strpos( $parsed_path, '/wp-login' ) ) {
                    continue;
                }
            }
            $link_status = rfx_get_final_destination_url( $url );
            if ( ! $link_status ) {
                continue;
            }
            $status    = (int) $link_status['status_code'];
            $final_url = $link_status['final_url'];
            // Broken link (4xx/5xx) → pending.  Skip logging if the same issue has already been recorded.
            if ( $status >= 400 ) {
                // Check if a pending record for this post and URL already exists to avoid duplicate entries.
                global $wpdb;
                $table_name = $wpdb->prefix . 'rfx_link_monitor';
                $existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table_name} WHERE post_id = %d AND original_url = %s AND resolution_status = %s", $post_id, $url, 'pending' ) );
                if ( ! $existing_id ) {
                    rfx_log_link_issue( $post_id, $url, '', $status, $link_status['status_message'], 'pending' );
                }
                continue;
            }
            // If the final URL differs from the original, decide whether to auto‑fix.
            if ( $final_url !== $url ) {
                /*
                 * By default all 3xx redirects (including permanent 301/308) are
                 * flagged as pending.  Only when the user has enabled
                 * automatic resolution will permanent redirects be updated in
                 * the content.  Temporary redirects (302/307) are always
                 * treated as pending.  We check the first hop code to
                 * determine redirect status.
                 */
                $first_hop = (int) $link_status['first_hop_code'];
                $is_redirect = ( $first_hop >= 300 && $first_hop < 400 );
                if ( $is_redirect ) {
                    // Determine if this is a permanent redirect.  If not, it's
                    // treated as temporary regardless of auto‑resolve setting.
                    $is_perm = ( $link_status['is_permanent'] && ( $first_hop === 301 || $first_hop === 308 ) );
                    if ( $is_perm && $auto_resolve && $status >= 200 && $status < 400 ) {
                        // Auto‑fix permanent redirect when enabled.  Replace only the attribute value.
                        $updated_content = str_replace( 'href="' . esc_attr( $url ) . '"', 'href="' . esc_attr( $final_url ) . '"', $updated_content );
                        // Only log the resolved entry if not already recorded.
                        global $wpdb;
                        $table_name  = $wpdb->prefix . 'rfx_link_monitor';
                        $existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table_name} WHERE post_id = %d AND original_url = %s AND resolution_status = %s", $post_id, $url, 'resolved' ) );
                        if ( ! $existing_id ) {
                            rfx_log_link_issue( $post_id, $url, $final_url, 301, __( 'Auto‑fixed (Permanent Redirect)', 'link-sentinel' ), 'resolved' );
                        }
                    } else {
                        // Treat any 3xx as pending.  Use the first hop code as the HTTP status.
                        global $wpdb;
                        $table_name  = $wpdb->prefix . 'rfx_link_monitor';
                        $existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table_name} WHERE post_id = %d AND original_url = %s AND resolution_status = %s", $post_id, $url, 'pending' ) );
                        if ( ! $existing_id ) {
                            // Label message depending on permanence.
                            $msg = $is_perm ? __( 'Permanent Redirect', 'link-sentinel' ) : __( 'Temporary Redirect', 'link-sentinel' );
                            rfx_log_link_issue( $post_id, $url, $final_url, $first_hop, $msg, 'pending' );
                        }
                    }
                }
            }
        }
        // Update post content if any changes were made.
        if ( $updated_content !== $content ) {
            wp_update_post( [ 'ID' => $post_id, 'post_content' => wp_slash( $updated_content ) ] );
        }
    }
}

/**
 * Enqueue a scan for all scannable posts.
 *
 * When executed this function will queue an asynchronous action per post
 * using Action Scheduler.  We update an option to record the time and
 * type of scan (manual or automatic) so that the resolved links display
 * can show how many links were fixed in the current scan versus previously.
 *
 * @param string $type Either 'manual' or 'automatic'.
 */
function rfx_enqueue_scan( $type = 'manual' ) {
    update_option( 'rfx_scan_last_started', current_time( 'mysql' ) );
    update_option( 'rfx_scan_last_type', $type );
    rfx_load_action_scheduler();
    if ( ! function_exists( 'as_enqueue_async_action' ) ) {
        return;
    }
    $post_ids = rfx_get_scannable_post_ids();
    foreach ( $post_ids as $post_id ) {
        as_enqueue_async_action( 'rfx_process_single_post_action', [ 'post_id' => $post_id ] );
    }
}

/**
 * Hook to run nightly scans as scheduled events.
 */
add_action( 'rfx_nightly_scan', function () {
    rfx_enqueue_scan( 'automatic' );
} );

/**
 * Register the asynchronous action that processes each post.
 */
add_action( 'rfx_process_single_post_action', function ( $args ) {
    if ( empty( $args['post_id'] ) ) {
        return;
    }
    rfx_process_single_post( (int) $args['post_id'] );
} );

/**
 * AJAX callback to start a manual scan.
 */
function rfx_ajax_start_scan() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Permission denied.', 'link-sentinel' ) ], 403 );
    }
    check_ajax_referer( 'rfx_start_scan_nonce' );
    // Retrieve list of posts/pages to scan.
    $post_ids = rfx_get_scannable_post_ids();
    if ( empty( $post_ids ) ) {
        wp_send_json_success( [ 'message' => __( 'No content found to scan based on your settings.', 'link-sentinel' ) ] );
    }
    /*
     * For manual scans we run the scan synchronously rather than relying
     * on Action Scheduler.  This avoids situations where the async
     * queue does not run in certain local environments (e.g. when WP Cron
     * is disabled) and provides immediate feedback to the user.
     */
    update_option( 'rfx_scan_last_started', current_time( 'mysql' ) );
    update_option( 'rfx_scan_last_type', 'manual' );
    foreach ( $post_ids as $post_id ) {
        rfx_process_single_post( (int) $post_id );
    }
    // Count new issues logged during this scan.  We use the scan_date to identify entries created since the scan started.
    global $wpdb;
    $table_name   = $wpdb->prefix . 'rfx_link_monitor';
    $last_started = get_option( 'rfx_scan_last_started' );
    $count        = 0;
    if ( $last_started ) {
        $count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM $table_name WHERE scan_date >= %s", $last_started ) );
    }
    if ( 0 === $count ) {
        wp_send_json_success( [ 'message' => __( 'Scan complete: no internal links were found in your content.', 'link-sentinel' ) ] );
    } else {
        wp_send_json_success( [ 'message' => sprintf( __( 'Scan complete: %d link(s) processed.', 'link-sentinel' ), $count ) ] );
    }
}

/**
 * AJAX callback to resolve a pending redirect immediately.
 *
 * This handler updates the affected post by replacing the original URL
 * with the detected final URL and marks the record as resolved in the
 * monitor table.  Only authenticated users with manage_options can
 * perform this action.  A generic nonce is used for CSRF protection.
 */
function rfx_ajax_resolve_link() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Permission denied.', 'link-sentinel' ) ], 403 );
    }
    // Validate request parameters.
    $id    = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
    $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
    if ( ! $id || ! wp_verify_nonce( $nonce, 'rfx_resolve_link_nonce' ) ) {
        wp_send_json_error( [ 'message' => __( 'Invalid request.', 'link-sentinel' ) ] );
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfx_link_monitor';
    // Fetch the pending record.
    $record = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d AND resolution_status = %s", $id, 'pending' ), ARRAY_A );
    if ( ! $record ) {
        wp_send_json_error( [ 'message' => __( 'Record not found or already resolved.', 'link-sentinel' ) ] );
    }
    // Ensure there is a final URL to replace with.
    if ( empty( $record['final_url'] ) ) {
        wp_send_json_error( [ 'message' => __( 'This link does not have a detected URL to resolve to.', 'link-sentinel' ) ] );
    }
    // Update the post content: replace the original URL with the final URL in the href attribute.
    $post        = get_post( $record['post_id'] );
    if ( $post && ! empty( $post->post_content ) ) {
        $search       = 'href="' . esc_attr( $record['original_url'] ) . '"';
        $replacement  = 'href="' . esc_attr( $record['final_url'] ) . '"';
        $updated      = str_replace( $search, $replacement, $post->post_content );
        // Only update if changes were made.
        if ( $updated !== $post->post_content ) {
            wp_update_post( [ 'ID' => $post->ID, 'post_content' => wp_slash( $updated ) ] );
        }
    }
    // Mark the record as resolved.
    $wpdb->update(
        $table_name,
        [
            'resolution_status' => 'resolved',
            'resolution_date'   => current_time( 'mysql' ),
            'status_message'    => __( 'Manually Resolved', 'link-sentinel' ),
        ],
        [ 'id' => $id ],
        [ '%s', '%s', '%s' ],
        [ '%d' ]
    );
    wp_send_json_success( [ 'message' => __( 'Link resolved successfully.', 'link-sentinel' ) ] );
}
add_action( 'wp_ajax_rfx_resolve_link', 'rfx_ajax_resolve_link' );

/**
 * AJAX callback to resolve all pending redirects in bulk.
 *
 * This handler loops through every pending record that has a detected final URL
 * and a status code under 400 (i.e. temporary redirects) and performs the
 * same operations as the single “Resolve Now” action: replace the original
 * link in the post content with the resolved URL and mark the entry as
 * resolved.  To prevent unauthorized requests, a nonce must be supplied via
 * the `nonce` parameter and verified against `rfx_resolve_all_nonce`.
 */
function rfx_ajax_resolve_all() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Permission denied.', 'link-sentinel' ) ], 403 );
    }
    $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
    if ( ! $nonce || ! wp_verify_nonce( $nonce, 'rfx_resolve_all_nonce' ) ) {
        wp_send_json_error( [ 'message' => __( 'Invalid request.', 'link-sentinel' ) ] );
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfx_link_monitor';
    // Fetch all pending records that have a final URL and a status < 400.
    $records = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE resolution_status = %s AND final_url <> '' AND ( http_status < %d OR http_status IS NULL )", 'pending', 400 ), ARRAY_A );
    if ( empty( $records ) ) {
        wp_send_json_success( [ 'message' => __( 'No pending redirects to resolve.', 'link-sentinel' ) ] );
    }
    foreach ( $records as $record ) {
        // Update the post content.
        $post = get_post( $record['post_id'] );
        if ( $post && ! empty( $post->post_content ) ) {
            $search      = 'href="' . esc_attr( $record['original_url'] ) . '"';
            $replacement = 'href="' . esc_attr( $record['final_url'] ) . '"';
            $updated     = str_replace( $search, $replacement, $post->post_content );
            if ( $updated !== $post->post_content ) {
                wp_update_post( [ 'ID' => $post->ID, 'post_content' => wp_slash( $updated ) ] );
            }
        }
        // Mark as resolved.
        $wpdb->update(
            $table_name,
            [
                'resolution_status' => 'resolved',
                'resolution_date'   => current_time( 'mysql' ),
                'status_message'    => __( 'Manually Resolved', 'link-sentinel' ),
            ],
            [ 'id' => $record['id'] ],
            [ '%s', '%s', '%s' ],
            [ '%d' ]
        );
    }
    wp_send_json_success( [ 'message' => __( 'All pending redirects have been resolved.', 'link-sentinel' ) ] );
}
add_action( 'wp_ajax_rfx_resolve_all', 'rfx_ajax_resolve_all' );

/**
 * AJAX callback to change a broken link manually.
 *
 * Allows administrators to supply a new URL for a broken link.  The original
 * URL in the post content is replaced with the supplied URL, and the log
 * entry is marked as resolved.  This handler accepts three POST fields:
 * `id` (the database record ID), `nonce` for CSRF protection, and
 * `new_url`, which must be a valid URL.  If the operation is successful,
 * the post content is updated and the row removed from the broken links
 * table on page reload.
 */
function rfx_ajax_change_link() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Permission denied.', 'link-sentinel' ) ], 403 );
    }
    $id      = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
    $nonce   = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
    $new_url = isset( $_POST['new_url'] ) ? trim( wp_unslash( $_POST['new_url'] ) ) : '';
    if ( ! $id || ! $nonce || ! $new_url ) {
        wp_send_json_error( [ 'message' => __( 'Missing data.', 'link-sentinel' ) ] );
    }
    if ( ! wp_verify_nonce( $nonce, 'rfx_change_link_nonce' ) ) {
        wp_send_json_error( [ 'message' => __( 'Invalid nonce.', 'link-sentinel' ) ] );
    }
    /*
     * Validate the new URL.  Accept absolute URLs as well as relative
     * slugs (paths beginning with '/').  If the provided value is a
     * relative path, we treat it as an internal URL and will store it
     * exactly as provided.  Otherwise we require a well‑formed URL.
     */
    $is_relative = false;
    if ( '/' === substr( $new_url, 0, 1 ) ) {
        // Prepend home_url for validation, but store the slug as is.
        $tmp_url     = home_url( $new_url );
        $is_relative = true;
    } else {
        $tmp_url = $new_url;
    }
    $sanitized_url = esc_url_raw( $tmp_url );
    if ( ! filter_var( $sanitized_url, FILTER_VALIDATE_URL ) ) {
        wp_send_json_error( [ 'message' => __( 'Please provide a valid URL or slug.', 'link-sentinel' ) ] );
    }
    // If relative, use the original slug value; otherwise use sanitized absolute URL.
    $new_url = $is_relative ? $new_url : $sanitized_url;
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfx_link_monitor';
    // Retrieve the record; it must be pending (broken) and have status >= 400.
    $record = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d AND resolution_status = %s AND http_status >= %d", $id, 'pending', 400 ), ARRAY_A );
    if ( ! $record ) {
        wp_send_json_error( [ 'message' => __( 'Record not found or not eligible for change.', 'link-sentinel' ) ] );
    }
    // Retrieve the post but defer updating its content until the new URL is validated.
    $post = get_post( $record['post_id'] );
    /*
     * Determine the HTTP status of the provided URL.  We call the same
     * helper used during scans to inspect the first hop without
     * automatically following redirects.  Based on the response we
     * decide whether to mark the entry as resolved, pending or leave it
     * unchanged.  A status of 200–299 is considered valid and will
     * update the post content.  Any 3xx status (301/302/307/308) is
     * flagged as a pending redirect.  Any 4xx/5xx status or network
     * error is treated as invalid and the update is aborted with an
     * error message.
     */
    $link_status = rfx_get_final_destination_url( $tmp_url );
    if ( ! $link_status ) {
        wp_send_json_error( [ 'message' => __( 'Unable to fetch the provided URL. Please try a different link.', 'link-sentinel' ) ] );
    }
    $status_code    = (int) $link_status['status_code'];
    $first_hop_code = (int) $link_status['first_hop_code'];
    // If the response is a redirect (3xx), flag as pending and do not update the post content.
    if ( $first_hop_code >= 300 && $first_hop_code < 400 ) {
        // Update the record: set final_url and http_status to the first hop code, mark as pending.
        $wpdb->update(
            $table_name,
            [
                'final_url'         => $new_url,
                'http_status'       => $first_hop_code,
                'resolution_status' => 'pending',
                'status_message'    => __( 'Temporary Redirect', 'link-sentinel' ),
                'resolution_date'   => null,
            ],
            [ 'id' => $record['id'] ],
            [ '%s', '%d', '%s', '%s', '%s' ],
            [ '%d' ]
        );
        wp_send_json_success( [ 'message' => __( 'The new URL redirects.  It has been flagged for review as a pending redirect.', 'link-sentinel' ) ] );
    }
    // If the response status is >= 400, treat as broken and abort.
    if ( $status_code >= 400 ) {
        wp_send_json_error( [ 'message' => sprintf( __( 'The provided URL returned a %d status and cannot be used.  Please choose a valid link.', 'link-sentinel' ), $status_code ) ] );
    }
    // Otherwise (status 2xx) we can update the link.
    // Update the post content with the new URL if it changed.
    if ( $post && ! empty( $post->post_content ) ) {
        $search      = 'href="' . esc_attr( $record['original_url'] ) . '"';
        $replacement = 'href="' . esc_attr( $new_url ) . '"';
        $updated     = str_replace( $search, $replacement, $post->post_content );
        if ( $updated !== $post->post_content ) {
            wp_update_post( [ 'ID' => $post->ID, 'post_content' => wp_slash( $updated ) ] );
        }
    }
    // Update the record to resolved with status 200.
    $wpdb->update(
        $table_name,
        [
            'final_url'         => $new_url,
            'http_status'       => 200,
            'resolution_status' => 'resolved',
            'status_message'    => __( 'Manually Updated', 'link-sentinel' ),
            'resolution_date'   => current_time( 'mysql' ),
        ],
        [ 'id' => $record['id'] ],
        [ '%s', '%d', '%s', '%s', '%s' ],
        [ '%d' ]
    );
    wp_send_json_success( [ 'message' => __( 'Link updated successfully.', 'link-sentinel' ) ] );
}
add_action( 'wp_ajax_rfx_change_link', 'rfx_ajax_change_link' );
add_action( 'wp_ajax_rfx_start_scan', 'rfx_ajax_start_scan' );

/**
 * AJAX callback to report scan progress.
 *
 * Returns the number of posts processed, remaining and whether a scan is running.
 */
function rfx_ajax_scan_status() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( [ 'message' => __( 'Permission denied.', 'link-sentinel' ) ], 403 );
    }
    check_ajax_referer( 'rfx_start_scan_nonce' );
    $post_ids     = rfx_get_scannable_post_ids();
    $total_posts  = is_array( $post_ids ) ? count( $post_ids ) : 0;
    $pending      = 0;
    $in_progress  = 0;
    $running      = false;
    if ( function_exists( 'as_get_scheduled_actions' ) ) {
        $pending_ids = as_get_scheduled_actions( [ 'hook' => 'rfx_process_single_post_action', 'status' => 'pending', 'per_page' => -1 ], 'ids' );
        $inprog_ids  = as_get_scheduled_actions( [ 'hook' => 'rfx_process_single_post_action', 'status' => 'in-progress', 'per_page' => -1 ], 'ids' );
        $pending     = is_array( $pending_ids ) ? count( $pending_ids ) : 0;
        $in_progress = is_array( $inprog_ids ) ? count( $inprog_ids ) : 0;
        $running     = ( $pending + $in_progress ) > 0;
    }
    $remaining = $pending + $in_progress;
    $processed = max( 0, $total_posts - $remaining );
    $message   = $running ? sprintf( __( 'Scanning... %1$d of %2$d processed', 'link-sentinel' ), $processed, $total_posts ) : __( 'No active scans.', 'link-sentinel' );
    wp_send_json_success( [
        'running'     => (bool) $running,
        'total_posts' => (int) $total_posts,
        'pending'     => (int) $pending,
        'in_progress' => (int) $in_progress,
        'remaining'   => (int) $remaining,
        'processed'   => (int) $processed,
        'message'     => $message,
    ] );
}
add_action( 'wp_ajax_rfx_scan_status', 'rfx_ajax_scan_status' );

/**
 * Register our admin page under Tools → LinkSentinel.
 */
function rfx_register_admin_menu() {
    add_management_page(
        __( 'LinkSentinel', 'link-sentinel' ),
        __( 'LinkSentinel', 'link-sentinel' ),
        'manage_options',
        'link-sentinel',
        'rfx_render_dashboard'
    );
}
add_action( 'admin_menu', 'rfx_register_admin_menu', 9 );

/**
 * Redirect legacy slugs and clean up old submenu entries.
 */
function rfx_admin_legacy_redirect() {
    if ( isset( $_GET['page'] ) && 'link-health-monitor' === $_GET['page'] ) {
        wp_safe_redirect( admin_url( 'tools.php?page=link-sentinel' ) );
        exit;
    }
}
add_action( 'admin_init', 'rfx_admin_legacy_redirect' );
add_action( 'admin_menu', function () {
    // Remove any leftover submenu registered under the old slug.
    remove_submenu_page( 'tools.php', 'link-health-monitor' );
}, 999 );

/**
 * Handle saving plugin settings from the settings tab.
 *
 * This function processes form submissions from the settings tab, updates
 * the `rfx_settings` option, and reschedules the nightly scan event.
 * It expects a nonce named `rfx_settings_nonce` and will only run for
 * users with the `manage_options` capability.
 */
function rfx_save_settings() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'Permission denied.', 'link-sentinel' ) );
    }
    if ( ! isset( $_POST['rfx_settings_nonce'] ) || ! wp_verify_nonce( $_POST['rfx_settings_nonce'], 'rfx_save_settings' ) ) {
        wp_die( __( 'Invalid nonce.', 'link-sentinel' ) );
    }
    // Sanitize and store settings.
    $hour   = isset( $_POST['scan_hour'] ) ? intval( $_POST['scan_hour'] ) : 2;
    $minute = isset( $_POST['scan_minute'] ) ? intval( $_POST['scan_minute'] ) : 0;
    // Post types selected (array of slugs).
    $post_types = [];
    if ( isset( $_POST['post_types'] ) && is_array( $_POST['post_types'] ) ) {
        foreach ( $_POST['post_types'] as $pt ) {
            $post_types[] = sanitize_key( $pt );
        }
    }
    if ( empty( $post_types ) ) {
        // Fallback to posts and pages if nothing selected.
        $post_types = [ 'post', 'page' ];
    }
    // Determine whether automatic resolution of permanent redirects is enabled.
    $auto_resolve = ( isset( $_POST['auto_resolve_permanent'] ) && $_POST['auto_resolve_permanent'] ) ? 1 : 0;

    $settings = [
        'scan_hour'            => max( 0, min( 23, $hour ) ),
        'scan_minute'          => max( 0, min( 59, $minute ) ),
        'post_types'           => $post_types,
        'auto_resolve_permanent' => $auto_resolve,
    ];
    update_option( 'rfx_settings', $settings );
    // Reschedule the daily event according to new settings.
    rfx_schedule_daily_scan();
    // Redirect back to the plugin page with a success flag.
    wp_safe_redirect( add_query_arg( 'settings-updated', 'true', admin_url( 'tools.php?page=link-sentinel#settings' ) ) );
    exit;
}
add_action( 'admin_post_rfx_save_settings', 'rfx_save_settings' );

/**
 * Base list table class to display resolved links with scope (current or previous scans).
 */
if ( ! class_exists( 'RFX_Resolved_Links_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
    class RFX_Resolved_Links_List_Table extends WP_List_Table {
        protected $scope = 'all';
        public function __construct() {
            parent::__construct( [
                'singular' => 'resolved_link',
                'plural'   => 'resolved_links',
                'ajax'     => false,
            ] );
        }
        /**
         * Set the scope for the table.  Accepts 'current', 'previous', or 'all'.
         *
         * @param string $scope Scope string.
         */
        public function set_scope( $scope ) {
            $this->scope = in_array( $scope, [ 'current', 'previous', 'all' ], true ) ? $scope : 'all';
        }
        public function get_columns() {
            return [
                'original_url'    => __( 'Original URL', 'link-sentinel' ),
                'final_url'       => __( 'Corrected To', 'link-sentinel' ),
                'status_message'  => __( 'Action Taken', 'link-sentinel' ),
                'post_id'         => __( 'Found In', 'link-sentinel' ),
                'resolution_date' => __( 'Date Corrected', 'link-sentinel' ),
            ];
        }
        public function get_sortable_columns() {
            return [ 'resolution_date' => [ 'resolution_date', true ] ];
        }
        public function column_default( $item, $column_name ) {
            switch ( $column_name ) {
                case 'original_url':
                    return '<code>' . esc_html( $item['original_url'] ) . '</code>';
                case 'final_url':
                    return '<code>' . esc_html( $item['final_url'] ) . '</code>';
                case 'status_message':
                    return esc_html( $item['status_message'] );
                case 'post_id':
                    $post_title = get_the_title( $item['post_id'] );
                    if ( empty( $post_title ) ) {
                        $post_title = sprintf( __( 'Post #%d', 'link-sentinel' ), $item['post_id'] );
                    }
                    $edit_link = get_edit_post_link( $item['post_id'] );
                    return sprintf( '<a href="%s">%s</a>', esc_url( $edit_link ), esc_html( $post_title ) );
                case 'resolution_date':
                    /*
                     * Display a dash when the resolution date is empty or contains a
                     * zeroed value.  WordPress and MySQL can sometimes return
                     * '0000-00-00 00:00:00' or other zero dates for uninitialized
                     * datetime columns.  Trim the value and check the prefix to
                     * catch any such placeholder.  If a valid timestamp exists,
                     * return it verbatim (escaped for output).
                     */
                    $date = isset( $item['resolution_date'] ) ? trim( $item['resolution_date'] ) : '';
                    if ( empty( $date ) ) {
                        return '&mdash;';
                    }
                    // Treat any date string starting with '0000-00-00' as empty.
                    if ( 0 === strpos( $date, '0000-00-00' ) ) {
                        return '&mdash;';
                    }
                    return esc_html( $date );
                default:
                    return '';
            }
        }
        public function no_items() {
            esc_html_e( 'No resolved items yet.', 'link-sentinel' );
        }
        public function prepare_items() {
            global $wpdb;
            $table_name = $wpdb->prefix . 'rfx_link_monitor';
            $per_page   = 20;
            $order     = ( isset( $_GET['order'] ) && 'asc' === strtolower( $_GET['order'] ) ) ? 'ASC' : 'DESC';
            $current_page = $this->get_pagenum();
            $last_started = get_option( 'rfx_scan_last_started' );
            $where_base  = "resolution_status = %s";
            $params_base = [ 'resolved' ];
            $where       = $where_base;
            $params      = $params_base;
            if ( 'current' === $this->scope && ! empty( $last_started ) ) {
                $where  = $where_base . ' AND resolution_date IS NOT NULL AND resolution_date >= %s';
                $params = array_merge( $params_base, [ $last_started ] );
            } elseif ( 'previous' === $this->scope && ! empty( $last_started ) ) {
                $where  = $where_base . ' AND (resolution_date IS NULL OR resolution_date < %s)';
                $params = array_merge( $params_base, [ $last_started ] );
            }
            // Total items
            $total_items = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM $table_name WHERE $where", $params ) );
            $this->set_pagination_args( [ 'total_items' => $total_items, 'per_page' => $per_page ] );
            $offset = ( $current_page - 1 ) * $per_page;
            // Retrieve items for the current page.
            $items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE $where ORDER BY resolution_date $order LIMIT %d OFFSET %d", array_merge( $params, [ $per_page, $offset ] ) ), ARRAY_A );
            $this->items = $items;
            $this->_column_headers = [ $this->get_columns(), [], $this->get_sortable_columns() ];
        }
    }
}

/**
 * Pending links list table.
 */
if ( ! class_exists( 'RFX_Pending_Links_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
    class RFX_Pending_Links_List_Table extends WP_List_Table {
        public function __construct() {
            parent::__construct( [
                'singular' => 'pending_link',
                'plural'   => 'pending_links',
                'ajax'     => false,
            ] );
        }
        public function get_columns() {
            return [
                'post_id'       => __( 'Post', 'link-sentinel' ),
                'original_url'  => __( 'Original URL', 'link-sentinel' ),
                'final_url'     => __( 'Detected URL', 'link-sentinel' ),
                'http_status'   => __( 'HTTP', 'link-sentinel' ),
                'status_message'=> __( 'Note', 'link-sentinel' ),
                'scan_date'     => __( 'Date Scanned', 'link-sentinel' ),
            ];
        }
        public function get_sortable_columns() {
            return [ 'scan_date' => [ 'scan_date', true ] ];
        }
        public function column_default( $item, $column_name ) {
            switch ( $column_name ) {
                case 'post_id':
                    $post_title = get_the_title( $item['post_id'] );
                    if ( empty( $post_title ) ) {
                        $post_title = sprintf( __( 'Post #%d', 'link-sentinel' ), $item['post_id'] );
                    }
                    $edit_link = get_edit_post_link( $item['post_id'] );
                    return sprintf( '<a href="%s">%s</a>', esc_url( $edit_link ), esc_html( $post_title ) );
                case 'original_url':
                    return '<code>' . esc_html( $item['original_url'] ) . '</code>';
                case 'final_url':
                    return ! empty( $item['final_url'] ) ? '<code>' . esc_html( $item['final_url'] ) . '</code>' : '';
                case 'http_status':
                    return esc_html( $item['http_status'] );
                case 'status_message':
                    return esc_html( $item['status_message'] );
                case 'scan_date':
                    return esc_html( $item['scan_date'] );
                default:
                    return '';
            }
        }
        public function no_items() {
            esc_html_e( 'Nothing to review. Great job!', 'link-sentinel' );
        }
        public function prepare_items() {
            global $wpdb;
            $table_name   = $wpdb->prefix . 'rfx_link_monitor';
            $per_page     = 20;
            $order        = ( isset( $_GET['order'] ) && 'asc' === strtolower( $_GET['order'] ) ) ? 'ASC' : 'DESC';
            $current_page = $this->get_pagenum();
            /*
             * Only include pending items that have not been resolved and have HTTP status codes below 400.
             * Broken links (status >= 400) are displayed exclusively in the Broken Links table.
             */
            $total_items  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM $table_name WHERE resolution_status = %s AND ( http_status < %d OR http_status IS NULL )", 'pending', 400 ) );
            $this->set_pagination_args( [ 'total_items' => $total_items, 'per_page' => $per_page ] );
            $offset       = ( $current_page - 1 ) * $per_page;
            $items        = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM $table_name WHERE resolution_status = %s AND ( http_status < %d OR http_status IS NULL ) ORDER BY scan_date $order LIMIT %d OFFSET %d",
                    'pending', 400, $per_page, $offset
                ),
                ARRAY_A
            );
            $this->items = $items;
            $this->_column_headers = [ $this->get_columns(), [], $this->get_sortable_columns() ];
        }

        /**
         * Custom column output for the original URL column.
         *
         * Displays the original URL as code and adds a "Resolve Now" row action
         * when there is a detected final URL available.  The action passes
         * the record ID and a nonce via data attributes for the JS handler.
         *
         * @param array  $item The current row data.
         * @return string HTML output for the column.
         */
        public function column_original_url( $item ) {
            $value   = '<code>' . esc_html( $item['original_url'] ) . '</code>';
            $actions = [];
            // Only show a resolve action if we have a final URL to replace with.
            if ( ! empty( $item['final_url'] ) ) {
                // Use a global nonce for all rows; verification happens server side.
                $nonce = wp_create_nonce( 'rfx_resolve_link_nonce' );
                $actions['resolve'] = sprintf(
                    '<a href="#" class="rfx-resolve-link" data-id="%1$s" data-nonce="%2$s">%3$s</a>',
                    esc_attr( $item['id'] ),
                    esc_attr( $nonce ),
                    esc_html__( 'Resolve Now', 'link-sentinel' )
                );
            }
            return $value . $this->row_actions( $actions );
        }
    }
}

/**
 * Broken links list table.
 *
 * Displays only pending items where the HTTP status code is 400 or greater,
 * which indicates a client or server error.  Broken links require manual
 * intervention from the user.  Columns largely mirror the pending table
 * but omit the 'Detected URL' column since the final URL may be blank.
 */
if ( ! class_exists( 'RFX_Broken_Links_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
    class RFX_Broken_Links_List_Table extends WP_List_Table {
        public function __construct() {
            parent::__construct( [
                'singular' => 'broken_link',
                'plural'   => 'broken_links',
                'ajax'     => false,
            ] );
        }
        public function get_columns() {
            /*
             * We insert a dedicated Change Link column immediately to the right of
             * the Original URL column.  This provides a consistent location for the
             * inline editing UI.  The order here determines column order on screen.
             */
            return [
                'post_id'       => __( 'Post', 'link-sentinel' ),
                'original_url'  => __( 'Original URL', 'link-sentinel' ),
                'change'        => __( 'Change Link', 'link-sentinel' ),
                'http_status'   => __( 'HTTP', 'link-sentinel' ),
                'status_message'=> __( 'Note', 'link-sentinel' ),
                'scan_date'     => __( 'Date Scanned', 'link-sentinel' ),
            ];
        }
        public function get_sortable_columns() {
            return [ 'scan_date' => [ 'scan_date', true ] ];
        }
        public function column_default( $item, $column_name ) {
            switch ( $column_name ) {
                case 'post_id':
                    $post_title = get_the_title( $item['post_id'] );
                    if ( empty( $post_title ) ) {
                        $post_title = sprintf( __( 'Post #%d', 'link-sentinel' ), $item['post_id'] );
                    }
                    $edit_link = get_edit_post_link( $item['post_id'] );
                    return sprintf( '<a href="%s">%s</a>', esc_url( $edit_link ), esc_html( $post_title ) );
                case 'original_url':
                    // Only output the URL itself in this column.  Change actions are
                    // rendered in a separate column to the right.
                    return '<code>' . esc_html( $item['original_url'] ) . '</code>';
                case 'http_status':
                    return esc_html( $item['http_status'] );
                case 'status_message':
                    return esc_html( $item['status_message'] );
                case 'scan_date':
                    return esc_html( $item['scan_date'] );
                default:
                    return '';
            }
        }
        public function no_items() {
            esc_html_e( 'No broken links found.', 'link-sentinel' );
        }

        /**
         * Custom output for the change column in the broken links table.
         *
         * We render a simple link labelled "Change".  When clicked, the
         * JavaScript will replace this cell with an inline form consisting
         * of a text input and a "Change" button.  The anchor stores the
         * record ID, nonce and original URL as data attributes for use by JS.
         *
         * @param array $item The current row.
         * @return string HTML for the Change column.
         */
        public function column_change( $item ) {
            $nonce = wp_create_nonce( 'rfx_change_link_nonce' );
            return sprintf(
                '<a href="#" class="rfx-change-inline" data-id="%1$s" data-nonce="%2$s" data-original-url="%3$s">%4$s</a>',
                esc_attr( $item['id'] ),
                esc_attr( $nonce ),
                esc_attr( $item['original_url'] ),
                esc_html__( 'Change', 'link-sentinel' )
            );
        }
        public function prepare_items() {
            global $wpdb;
            $table_name   = $wpdb->prefix . 'rfx_link_monitor';
            $per_page     = 20;
            $order        = ( isset( $_GET['order'] ) && 'asc' === strtolower( $_GET['order'] ) ) ? 'ASC' : 'DESC';
            $current_page = $this->get_pagenum();
            // Only pending items with status >= 400 are considered broken.
            $total_items  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM $table_name WHERE resolution_status = %s AND http_status >= %d", 'pending', 400 ) );
            $this->set_pagination_args( [ 'total_items' => $total_items, 'per_page' => $per_page ] );
            $offset       = ( $current_page - 1 ) * $per_page;
            $items        = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM $table_name WHERE resolution_status = %s AND http_status >= %d ORDER BY scan_date $order LIMIT %d OFFSET %d",
                    'pending', 400, $per_page, $offset
                ),
                ARRAY_A
            );
            $this->items  = $items;
            $this->_column_headers = [ $this->get_columns(), [], $this->get_sortable_columns() ];
        }
    }
}

/**
 * Render the plugin dashboard page.
 */
function rfx_render_dashboard() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'You do not have permission to access this page.', 'link-sentinel' ) );
    }
    echo '<div class="wrap">';
    echo '<h1>' . esc_html__( 'LinkSentinel', 'link-sentinel' ) . '</h1>';

    // Last scan information.
    $last_started = get_option( 'rfx_scan_last_started' );
    $last_type    = get_option( 'rfx_scan_last_type' );
    if ( ! empty( $last_started ) ) {
        $type_label = ( 'manual' === $last_type ) ? esc_html__( 'Manual', 'link-sentinel' ) : esc_html__( 'Automatic', 'link-sentinel' );
        echo '<p style="margin: 8px 0 16px; color:#50575e;">' . esc_html__( 'Last scan:', 'link-sentinel' ) . ' ' . esc_html( $last_started ) . ' (' . $type_label . ')</p>';
    }

    // Top card: Scan & Schedule.
    echo '<div class="postbox" style="padding:16px 24px; margin-bottom:20px;">';
    echo '<h2 style="margin-top:0;">' . esc_html__( 'Scan & Schedule', 'link-sentinel' ) . '</h2>';
    echo '<p>' . esc_html__( 'Run an immediate scan or manage the automated daily scan schedule.', 'link-sentinel' ) . '</p>';
    echo '<div style="display:flex; gap:8px; flex-wrap:wrap;">';
    // Manage Schedule button toggles settings tab.
    echo '<button type="button" id="rfx-manage-schedule" class="button">' . esc_html__( 'Manage Schedule', 'link-sentinel' ) . '</button>';
    echo '<button type="button" id="rfx-start-scan" class="button button-primary">' . esc_html__( 'Scan Now', 'link-sentinel' ) . '</button>';
    echo '<span id="rfx-scan-feedback" style="display:none; margin-left:10px; align-self:center;"></span>';
    echo '</div>';
    // Progress bar container (hidden by default)
    echo '<div id="rfx-scan-status" class="notice notice-info" style="display:none; padding:10px; margin-top:12px;">';
    echo '<p style="margin:0; display:flex; align-items:center; gap:8px;"><span class="spinner is-active" style="float:none; visibility:visible;"></span><strong>' . esc_html__( 'Scan in progress', 'link-sentinel' ) . '</strong> <span id="rfx-scan-status-text"></span></p>';
    echo '<div style="background:#e5e5e5; height:8px; border-radius:4px; margin-top:8px; overflow:hidden;"><div id="rfx-scan-progress" style="height:8px; width:0; background:#2271b1;"></div></div>';
    echo '</div>';
    echo '</div>'; // end postbox

    /*
     * Generate tab navigation with counts for pending and broken items.  We
     * intentionally omit counts on resolved and settings tabs.  Pending
     * redirects include entries flagged for manual review (HTTP status < 400).
     * Broken links include any unresolved links with status >= 400.
     */
    global $wpdb;
    $pending_count_nav = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$wpdb->prefix}rfx_link_monitor WHERE resolution_status = %s AND ( http_status < %d OR http_status IS NULL )", 'pending', 400 ) );
    $broken_count_nav  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$wpdb->prefix}rfx_link_monitor WHERE resolution_status = %s AND http_status >= %d", 'pending', 400 ) );
    echo '<h2 class="nav-tab-wrapper">';
    echo '<a href="#resolved" class="nav-tab nav-tab-active">' . esc_html__( 'Resolved Links', 'link-sentinel' ) . '</a>';
    echo '<a href="#pending" class="nav-tab">' . sprintf( esc_html__( 'Pending Redirects (%d)', 'link-sentinel' ), $pending_count_nav ) . '</a>';
    echo '<a href="#broken" class="nav-tab">' . sprintf( esc_html__( 'Broken Links (%d)', 'link-sentinel' ), $broken_count_nav ) . '</a>';
    echo '<a href="#settings" class="nav-tab">' . esc_html__( 'Settings', 'link-sentinel' ) . '</a>';
    echo '</h2>';

    // Resolved tab content: single table for all resolved links with CSV export and clear options.
    echo '<div id="resolved" class="tab-content" style="display:block;">';
    echo '<form method="post">';
    // Build export URL with nonce for CSV download.
    $export_nonce = wp_create_nonce( 'rfx_export_resolved_csv' );
    $export_url   = add_query_arg( [
        'action'   => 'rfx_export_resolved_csv',
        '_wpnonce' => $export_nonce,
    ], admin_url( 'admin-post.php' ) );
    /*
     * Header with export and clear options.
     * We build both the CSV download link and a Clear Table link here.  The clear
     * link includes a nonce for security and an inline confirmation dialog to
     * prevent accidental deletion.  Only resolved items are affected.
     */
    // Nonce and URL for clearing the resolved table.
    $clear_nonce = wp_create_nonce( 'rfx_clear_resolved_links' );
    $clear_url   = add_query_arg( [
        'action'   => 'rfx_clear_resolved_links',
        '_wpnonce' => $clear_nonce,
    ], admin_url( 'admin-post.php' ) );
    echo '<div style="display:flex; justify-content:space-between; align-items:center;">';
    // Heading on the left
    echo '<h3 style="margin-top:10px;">' . esc_html__( 'Resolved Links', 'link-sentinel' ) . '</h3>';
    // Links on the right
    echo '<div style="display:flex; gap:8px;">';
    // Clear Table button with confirmation; uses a simple JS confirm dialog.
    echo '<a href="' . esc_url( $clear_url ) . '" class="button" onclick="return confirm(\'' . esc_js( __( 'Are you sure you want to clear all resolved links? This action cannot be undone.', 'link-sentinel' ) ) . '\');">' . esc_html__( 'Clear Table', 'link-sentinel' ) . '</a>';
    // Download CSV button
    echo '<a href="' . esc_url( $export_url ) . '" class="button">' . esc_html__( 'Download CSV', 'link-sentinel' ) . '</a>';
    echo '</div>';
    echo '</div>';
    // Display the full resolved list table (all scopes).
    $resolved_table = new RFX_Resolved_Links_List_Table();
    $resolved_table->set_scope( 'all' );
    $resolved_table->prepare_items();
    $resolved_table->display();
    echo '</form>';
    echo '</div>'; // resolved tab

    // Pending redirects tab content
    echo '<div id="pending" class="tab-content" style="display:none;">';
    echo '<form method="post">';
    // Heading with Resolve All button on the right. Only show if there are pending redirects.
    global $wpdb;
    $pending_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(id) FROM {$wpdb->prefix}rfx_link_monitor WHERE resolution_status = %s AND final_url <> '' AND ( http_status < %d OR http_status IS NULL )", 'pending', 400 ) );
    echo '<div style="display:flex; justify-content:space-between; align-items:center;">';
    echo '<h3 style="margin-top:10px;">' . esc_html__( 'Pending Redirects', 'link-sentinel' ) . '</h3>';
    if ( $pending_count > 0 ) {
        $resolve_all_nonce = wp_create_nonce( 'rfx_resolve_all_nonce' );
        echo '<button type="button" id="rfx-resolve-all" class="button button-secondary" data-nonce="' . esc_attr( $resolve_all_nonce ) . '" style="margin-bottom:4px;">' . esc_html__( 'Resolve All', 'link-sentinel' ) . '</button>';
    }
    echo '</div>';
    $pend_table = new RFX_Pending_Links_List_Table();
    $pend_table->prepare_items();
    $pend_table->display();
    echo '</form>';
    echo '</div>'; // pending tab

    // Broken links tab content
    echo '<div id="broken" class="tab-content" style="display:none;">';
    echo '<form method="post">';
    $broken_table = new RFX_Broken_Links_List_Table();
    $broken_table->prepare_items();
    $broken_table->display();
    echo '</form>';
    echo '</div>'; // broken tab

    // Settings tab content
    echo '<div id="settings" class="tab-content" style="display:none;">';
    // Settings heading
    echo '<h3>' . esc_html__( 'Settings', 'link-sentinel' ) . '</h3>';
    // Show success notice if settings were updated.
    if ( isset( $_GET['settings-updated'] ) && 'true' === $_GET['settings-updated'] ) {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings updated.', 'link-sentinel' ) . '</p></div>';
    }
    // Fetch current settings to pre-populate form.
    $settings = get_option( 'rfx_settings', [] );
    $current_hour   = isset( $settings['scan_hour'] ) ? intval( $settings['scan_hour'] ) : 2;
    $current_minute = isset( $settings['scan_minute'] ) ? intval( $settings['scan_minute'] ) : 0;
    $current_types  = ( isset( $settings['post_types'] ) && is_array( $settings['post_types'] ) ) ? $settings['post_types'] : [ 'post', 'page' ];
    echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
    // Nonce and action
    wp_nonce_field( 'rfx_save_settings', 'rfx_settings_nonce' );
    echo '<input type="hidden" name="action" value="rfx_save_settings" />';
    // Schedule time field
    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr valign="top">';
    echo '<th scope="row">' . esc_html__( 'Daily scan time', 'link-sentinel' ) . '</th>';
    echo '<td>';
    echo '<select name="scan_hour">';
    for ( $h = 0; $h < 24; $h++ ) {
        printf( '<option value="%d" %s>%02d</option>', $h, selected( $current_hour, $h, false ), $h );
    }
    echo '</select> : ';
    echo '<select name="scan_minute">';
    for ( $m = 0; $m < 60; $m += 5 ) {
        printf( '<option value="%d" %s>%02d</option>', $m, selected( $current_minute, $m, false ), $m );
    }
    echo '</select> ';
    echo '<p class="description">' . esc_html__( 'Choose the time of day when the automatic daily scan runs (site time).', 'link-sentinel' ) . '</p>';
    echo '</td>';
    echo '</tr>';

    // Automatic permanent redirect resolution option.
    $auto_resolve_setting = ( isset( $settings['auto_resolve_permanent'] ) && $settings['auto_resolve_permanent'] );
    echo '<tr valign="top">';
    echo '<th scope="row">' . esc_html__( 'Auto‑resolve permanent redirects', 'link-sentinel' ) . '</th>';
    echo '<td>';
    printf(
        '<label><input type="checkbox" name="auto_resolve_permanent" value="1" %s /> %s</label>',
        checked( true, $auto_resolve_setting, false ),
        esc_html__( 'Automatically update links that return a 301 or 308 status when scanning.', 'link-sentinel' )
    );
    echo '<p class="description">' . esc_html__( 'When enabled, permanently redirected links will be updated without requiring manual review.', 'link-sentinel' ) . '</p>';
    echo '</td>';
    echo '</tr>';
    // Post types field
    echo '<tr valign="top">';
    echo '<th scope="row">' . esc_html__( 'Post types to scan', 'link-sentinel' ) . '</th>';
    echo '<td>';
    // Retrieve all public post types.
    $public_types = get_post_types( [ 'public' => true ], 'objects' );
    foreach ( $public_types as $type ) {
        printf(
            '<label style="display:inline-block; margin-right:10px;"><input type="checkbox" name="post_types[]" value="%s" %s /> %s</label>',
            esc_attr( $type->name ),
            checked( in_array( $type->name, $current_types, true ), true, false ),
            esc_html( $type->labels->singular_name )
        );
    }
    echo '<p class="description">' . esc_html__( 'Select which post types should be included in scans. Defaults to posts and pages.', 'link-sentinel' ) . '</p>';
    echo '</td>';
    echo '</tr>';
    echo '</tbody></table>';
    echo '<p><button type="submit" class="button button-primary">' . esc_html__( 'Save Settings', 'link-sentinel' ) . '</button></p>';
    echo '</form>';
    echo '</div>'; // settings tab

    echo '</div>'; // tab wrapper

    /*
     * Copyright notice
     *
     * Display a footer at the bottom of the dashboard with the current year
     * and a link back to Coquina Works.  Use date_i18n() to honour the site
     * timezone and translation settings.  The year will update automatically
     * each calendar year.  The copyright symbol uses HTML entity for
     * consistent rendering.
     */
    $current_year = date_i18n( 'Y' );
    echo '<p style="margin-top:20px; text-align:center; color:#777; font-size:13px;">&copy;' . esc_html( $current_year ) . ' <a href="https://www.coquinaworks.com" target="_blank" rel="noopener">' . esc_html__( 'Coquina Works', 'link-sentinel' ) . '</a>.</p>';

    echo '</div>'; // wrap
}

/**
 * Export resolved links to a CSV file.
 *
 * Generates a CSV of all entries marked as resolved in the `rfx_link_monitor`
 * table.  Users must have `manage_options` capability to initiate the export.
 * A valid nonce must be supplied via the `_wpnonce` query parameter.  The
 * resulting file is output directly to the browser and terminates script
 * execution via exit().
 */
function rfx_export_resolved_csv() {
    // Only administrators can export data.
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'You do not have permission to access this export.', 'link-sentinel' ) );
    }
    // Verify the nonce to protect against CSRF.
    check_admin_referer( 'rfx_export_resolved_csv' );
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfx_link_monitor';
    // Retrieve all resolved rows ordered by resolution date (latest first).
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE resolution_status = %s ORDER BY resolution_date DESC", 'resolved' ), ARRAY_A );
    // Send headers to prompt a CSV download.
    header( 'Content-Type: text/csv; charset=utf-8' );
    header( 'Content-Disposition: attachment; filename=resolved-links-' . gmdate( 'Y-m-d_H-i-s' ) . '.csv' );
    // Open a stream to PHP output.
    $output = fopen( 'php://output', 'w' );
    // Output column headings.
    fputcsv( $output, [ 'ID', 'Post ID', 'Original URL', 'Final URL', 'HTTP Status', 'Action', 'Scan Date', 'Resolution Date' ] );
    // Output each row.
    foreach ( $rows as $row ) {
        fputcsv( $output, [
            $row['id'],
            $row['post_id'],
            $row['original_url'],
            $row['final_url'],
            $row['http_status'],
            $row['status_message'],
            $row['scan_date'],
            $row['resolution_date'],
        ] );
    }
    fclose( $output );
    exit;
}

/**
 * Admin action to clear all resolved links from the log table.
 *
 * When the Clear Table link is clicked on the Resolved Links tab, this
 * function runs.  It verifies the user's capability and nonce, then
 * deletes all rows in the log table where the resolution_status is
 * 'resolved'.  After deletion, the user is redirected back to the
 * Resolved Links tab.  A simple confirm dialog is presented via
 * JavaScript on the link itself to avoid accidental deletion.
 */
function rfx_clear_resolved_links() {
    // Only administrators may clear the table.
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'Permission denied.', 'link-sentinel' ) );
    }
    // Verify nonce for security.
    check_admin_referer( 'rfx_clear_resolved_links' );
    global $wpdb;
    $table_name = $wpdb->prefix . 'rfx_link_monitor';
    // Delete all resolved rows.
    $wpdb->delete( $table_name, [ 'resolution_status' => 'resolved' ], [ '%s' ] );
    // Redirect back to the Resolved tab with a query flag to display a notice (optional).
    $redirect_url = add_query_arg( [ 'page' => 'link-sentinel', 'tab' => 'resolved', 'cleared' => '1' ], admin_url( 'tools.php' ) );
    wp_safe_redirect( $redirect_url );
    exit;
}

// Register the clear resolved action for admin_post.
add_action( 'admin_post_rfx_clear_resolved_links', 'rfx_clear_resolved_links' );

// Register export handlers for logged‑in and non‑logged‑in contexts (nonce is still required).
add_action( 'admin_post_rfx_export_resolved_csv', 'rfx_export_resolved_csv' );
add_action( 'admin_post_nopriv_rfx_export_resolved_csv', 'rfx_export_resolved_csv' );