/*
 * Admin JavaScript for LinkSentinel.
 *
 * Handles tab navigation, kicking off scans, polling for progress and
 * updating the UI accordingly.  This script runs only on the plugin
 * dashboard page because it is enqueued conditionally in PHP.
 */
(function ( $ ) {
    'use strict';
    $( document ).ready( function () {
        // Tab navigation: show/hide content on click.
        const $tabs        = $( '.nav-tab-wrapper a.nav-tab' );
        const $tabContents = $( '.tab-content' );
        $tabs.on( 'click', function ( e ) {
            e.preventDefault();
            const target = $( this ).attr( 'href' );
            // Switch the active class to the clicked tab and toggle content.
            $tabs.removeClass( 'nav-tab-active' );
            $( this ).addClass( 'nav-tab-active' );
            $tabContents.hide();
            $( target ).show();
            /*
             * Update the activeTab variable whenever a tab is clicked, but
             * explicitly ignore the Settings tab.  The Settings tab is
             * primarily used for configuring scan schedules and does not
             * represent a state we want to return to after scans complete.
             * Without this guard, navigating to the Settings tab would
             * overwrite the previously active tab (e.g. Resolved, Pending
             * or Broken) causing the dashboard to reopen on the Settings
             * tab after an auto‑fix, which is confusing.  See #233 for
             * details.
             */
            if ( target !== '#settings' ) {
                activeTab = target || null;
            }
        } );
        // Capture the currently active tab at page load.  If a scan is already
        // in progress when the user visits or refreshes the page (for example,
        // a nightly scan running in the background), we need to know which
        // tab was selected so we can return to it when the scan completes.
        let activeTab = $( '.nav-tab-wrapper a.nav-tab-active' ).attr( 'href' ) || null;

        // Scan button handler.
        const $scanBtn = $( '#rfx-start-scan' );
        const $feedback = $( '#rfx-scan-feedback' );
        const $statusBox = $( '#rfx-scan-status' );
        const $statusText = $( '#rfx-scan-status-text' );
        const $progressBar = $( '#rfx-scan-progress' );
        let pollTimer = null;
        function updateUI( data ) {
            if ( ! data ) return;
            if ( data.running ) {
                $statusBox.show();
                const total     = data.total_posts || 0;
                const processed = data.processed || 0;
                const pct       = total > 0 ? Math.min( 100, Math.round( ( processed / total ) * 100 ) ) : 0;
                $statusText.text( ' ' + ( data.message || '' ) );
                $progressBar.css( 'width', pct + '%' );
            } else {
                $statusBox.hide();
            }
        }
        function pollStatusOnce( cb ) {
            $.ajax( {
                url: ( window.RFXAdmin && RFXAdmin.ajax_url ) || ajaxurl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'rfx_scan_status',
                    _ajax_nonce: ( window.RFXAdmin && RFXAdmin.nonce ) || '',
                },
            } ).done( function ( res ) {
                if ( res && res.success ) {
                    updateUI( res.data );
                    if ( typeof cb === 'function' ) {
                        cb( res.data );
                    }
                }
            } );
        }
        /*
         * Capture the currently active tab before starting a scan.
         * When the scan finishes we will restore this tab by setting
         * window.location.hash to its href.  Without this, the page
         * reload after a scan always defaults back to the first tab (Resolved),
         * or unexpectedly switches to the Settings tab in some cases.
         */
        // NOTE: activeTab is initialized above to the current tab on page load.
        // It is reset here in the scan click handler to whatever tab is active
        // when the user explicitly starts a scan.
        // When a scan runs automatically (without clicking the button), the
        // initial value will be used.
        function startPolling() {
            if ( pollTimer ) return;
            pollTimer = setInterval( function () {
                pollStatusOnce( function ( data ) {
                    // If the scan has finished, show a processing state before reloading.
                    if ( data && ! data.running ) {
                        clearInterval( pollTimer );
                        pollTimer = null;
                        /*
                         * Display a processing message and set the progress bar to 100% so the
                         * user sees that results are being finalised.  Then reload after
                         * a short delay to update the counts and tables.  We restore the
                         * previously active tab via the URL hash.
                         */
                        $statusBox.show();
                        $statusText.text( ' Processing results…' );
                        $progressBar.css( 'width', '100%' );
                        setTimeout( function () {
                            window.location.hash = activeTab || '';
                            window.location.reload();
                        }, 1500 );
                    }
                } );
            }, 3000 );
        }

        // Automatically check the scan status every 30 seconds in case a scan
        // starts after the page has loaded (e.g. via the daily cron).  When a
        // running scan is detected, start polling for progress.
        var autoStatusInterval = null;
        autoStatusInterval = setInterval( function () {
            pollStatusOnce( function ( data ) {
                if ( data && data.running && ! pollTimer ) {
                    startPolling();
                }
            } );
        }, 30000 );
        // Start scan click.
        $scanBtn.on( 'click', function () {
            // Capture the currently active tab's href so we can return to it
            // when the scan completes.  Defaults to null if none found.
            activeTab = $( '.nav-tab-wrapper a.nav-tab-active' ).attr( 'href' ) || null;
            $scanBtn.prop( 'disabled', true );
            $feedback.text( 'Starting...' ).show();
            $statusBox.show();
            startPolling();
            $.ajax( {
                url: ( window.RFXAdmin && RFXAdmin.ajax_url ) || ajaxurl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'rfx_start_scan',
                    _ajax_nonce: ( window.RFXAdmin && RFXAdmin.nonce ) || '',
                },
            } ).done( function ( res ) {
                if ( res && res.success ) {
                    $feedback.text( res.data && res.data.message ? res.data.message : 'Scan queued.' );
                } else {
                    if ( res && res.data && res.data.message ) {
                        $feedback.text( res.data.message );
                    } else {
                        $feedback.text( 'Unexpected response.' );
                    }
                }
            } ).fail( function () {
                $feedback.text( 'Server error.' );
            } ).always( function () {
                $scanBtn.prop( 'disabled', false );
            } );
        } );
        // On page load, check if a scan is in progress and start polling.
        pollStatusOnce( function ( data ) {
            if ( data && data.running ) {
                startPolling();
            }
        } );

        /*
         * If the URL contains a hash (e.g. #broken or #pending) when the page
         * loads, activate the corresponding tab automatically.  This
         * supports returning to the same tab after an action that reloads
         * the page, such as changing a broken link.  We trigger a click
         * event on the matching tab to reuse the existing navigation
         * handler.
         */
        ( function () {
            const hash = window.location.hash;
            if ( hash ) {
                const $target = $( '.nav-tab-wrapper a[href="' + hash + '"]' );
                if ( $target.length ) {
                    // Defer the trigger to ensure the DOM is fully initialized.
                    setTimeout( function () {
                        $target.trigger( 'click' );
                    }, 0 );
                }
            }
        } )();

        // Manage schedule button toggles to the settings tab.
        $( '#rfx-manage-schedule' ).on( 'click', function () {
            // Switch tab active state.
            $tabs.removeClass( 'nav-tab-active' );
            // Activate the settings tab.
            $( '.nav-tab-wrapper a[href="#settings"]' ).addClass( 'nav-tab-active' );
            // Hide all tab contents and show settings.
            $tabContents.hide();
            $( '#settings' ).show();
            // Scroll to the settings section for convenience.
            if ( typeof window.scrollTo === 'function' ) {
                window.scrollTo( { top: $( '#settings' ).offset().top - 50, behavior: 'smooth' } );
            }
        } );

        /*
         * Resolve a pending redirect immediately when the user clicks the
         * "Resolve Now" link in the pending redirects table.  The link
         * includes data attributes for the record ID and a nonce.  Upon
         * completion the page will refresh to show the updated tables.
         */
        $( document ).on( 'click', '.rfx-resolve-link', function ( e ) {
            e.preventDefault();
            const $btn  = $( this );
            const id    = $btn.data( 'id' );
            const nonce = $btn.data( 'nonce' );
            if ( ! id || ! nonce ) {
                return;
            }
            // Provide immediate feedback.
            const originalText = $btn.text();
            $btn.text( 'Resolving…' );
            $.ajax( {
                url: ( window.RFXAdmin && RFXAdmin.ajax_url ) || ajaxurl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'rfx_resolve_link',
                    id: id,
                    nonce: nonce,
                },
            } ).done( function ( res ) {
                if ( res && res.success ) {
                    /*
                     * Stay on the Pending tab after resolving a single redirect.  By
                     * setting the URL hash to #pending before reloading, the
                     * document ready handler will pick up the hash and activate
                     * the corresponding tab after page load.  Without this the
                     * interface may default to another tab.
                     */
                    window.location.hash = '#pending';
                    window.location.reload();
                } else {
                    // Display error and restore text.
                    if ( res && res.data && res.data.message ) {
                        alert( res.data.message );
                    } else {
                        alert( 'An error occurred while resolving the link.' );
                    }
                    $btn.text( originalText );
                }
            } ).fail( function () {
                alert( 'Server error while resolving the link.' );
                $btn.text( originalText );
            } );
        } );

        /*
         * Resolve all pending redirects at once.  When the user clicks the
         * "Resolve All" button above the pending table, we gather the nonce
         * from the button’s data attribute and send an AJAX request to
         * rfx_resolve_all.  On success the page reloads to reflect the
         * newly resolved items.
         */
        $( document ).on( 'click', '#rfx-resolve-all', function ( e ) {
            e.preventDefault();
            var $btn = $( this );
            var nonce = $btn.data( 'nonce' );
            if ( ! nonce ) {
                return;
            }
            // Provide immediate feedback and disable the button to prevent double clicks.
            var originalText = $btn.text();
            $btn.prop( 'disabled', true ).text( 'Resolving…' );
            $.ajax( {
                url: ( window.RFXAdmin && RFXAdmin.ajax_url ) || ajaxurl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'rfx_resolve_all',
                    nonce: nonce,
                },
            } ).done( function ( res ) {
                if ( res && res.success ) {
                    /*
                     * After bulk resolving all pending redirects we want to
                     * remain on the Pending tab.  Setting the URL hash ensures
                     * the correct tab is activated on reload.
                     */
                    window.location.hash = '#pending';
                    window.location.reload();
                } else {
                    if ( res && res.data && res.data.message ) {
                        alert( res.data.message );
                    } else {
                        alert( 'An error occurred while resolving redirects.' );
                    }
                    $btn.prop( 'disabled', false ).text( originalText );
                }
            } ).fail( function () {
                alert( 'Server error while resolving redirects.' );
                $btn.prop( 'disabled', false ).text( originalText );
            } );
        } );

        /*
         * Change a broken link directly from the Broken Links table.
         * When the user clicks the "Change" link in the dedicated column,
         * we dynamically replace the link with an inline form.  The form
         * consists of a text input (pre‑filled with the original URL) and
         * a "Change" button.  Submitting the form sends an AJAX request
         * to rfx_change_link.  On success the page reloads and the item
         * appears in the Resolved list.
         */
        $( document ).on( 'click', '.rfx-change-inline', function ( e ) {
            e.preventDefault();
            const $link   = $( this );
            const id      = $link.data( 'id' );
            const nonce   = $link.data( 'nonce' );
            const origUrl = $link.data( 'original-url' );
            if ( ! id || ! nonce ) {
                return;
            }
            const $td = $link.closest( 'td' );
            // If an editor is already present, do nothing to avoid duplicates.
            if ( $td.find( '.rfx-change-editor' ).length ) {
                return;
            }
            // Build inline editor elements.
            const $container = $( '<span class="rfx-change-editor" />' );
            const $input     = $( '<input type="text" class="regular-text" style="width:65%; margin-right:6px;" />' ).val( origUrl );
            const $button    = $( '<button type="button" class="button button-primary">' + 'Change' + '</button>' );
            // Replace the cell contents with the editor.
            $container.append( $input ).append( $button );
            $td.data( 'orig-html', $td.html() );
            $td.empty().append( $container );
            // Handle Change button click.
            $button.on( 'click', function () {
                const newUrl = $.trim( $input.val() );
                if ( ! newUrl ) {
                    alert( 'Please enter a URL or slug.' );
                    return;
                }
                // Disable UI during processing.
                $button.prop( 'disabled', true ).text( 'Changing…' );
                $.ajax( {
                    url: ( window.RFXAdmin && RFXAdmin.ajax_url ) || ajaxurl,
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'rfx_change_link',
                        id: id,
                        nonce: nonce,
                        new_url: newUrl
                    },
                } ).done( function ( res ) {
                    if ( res && res.success ) {
                        /*
                         * Stay on the Broken Links tab after a successful change.  By
                         * setting the URL hash before reloading, we can trigger
                         * automatic tab switching on page load.  The document ready
                         * handler will read the hash and activate the corresponding tab.
                         */
                        window.location.hash = '#broken';
                        window.location.reload();
                    } else {
                        if ( res && res.data && res.data.message ) {
                            alert( res.data.message );
                        } else {
                            alert( 'An error occurred while updating the link.' );
                        }
                        $button.prop( 'disabled', false ).text( 'Change' );
                    }
                } ).fail( function () {
                    alert( 'Server error while updating the link.' );
                    $button.prop( 'disabled', false ).text( 'Change' );
                } );
            } );
        } );
    } );
})( jQuery );