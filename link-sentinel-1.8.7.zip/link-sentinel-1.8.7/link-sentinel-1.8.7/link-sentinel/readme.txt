=== LinkSentinel ===
Contributors: coquinaworks
Tags: links, redirects, 301, 302, broken links, scan
Requires at least: 5.8
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.8.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://www.ko-fi.com/coquinaworks

Scan your site for redirected or broken internal links. Auto-fix 301/308 (optional), queue 302/307 & 4xx for review, schedule scans, and export fixes.

== Description ==

**LinkSentinel** keeps your site healthy by scanning internal links in your posts and pages. It detects redirects and broken destinations without following all hops blindly, letting you focus on what matters:

* Auto-fixes links that are permanently redirected (HTTP 301/308). Your content stays up to date without manual editing.
* Lists temporary redirects (302/307) and broken links for manual review.
* Runs asynchronously in the background using Action Scheduler (bundled or detected from WooCommerce).
* Provides a dashboard under **Tools <span aria-hidden="true" class="wp-exclude-emoji">→</span> LinkSentinel** with tabs for resolved links, pending redirects, broken links, and settings.
* Allows you to download all resolved links as a CSV file for your records or further analysis.
* Shows progress while scanning so you know how many items have been processed.
* Tracks when the last scan started and whether it was initiated manually or automatically via the daily schedule.

**What you get (Free)**

* Automatic scans: Run on demand or on a daily schedule.
* Accurate detection: Flags 3xx redirects and 4xx/5xx errors in your internal links (posts, pages, media).
* Smart handling:
  * 301/308 (permanent) can be auto-fixed to the final URL (toggle in Settings).
  * 302/307 (temporary) and 4xx/5xx are queued for manual review.
  * Inline fixes: Update broken links right from the table—no need to open the editor.
  * Resolve All: Batch-resolve pending redirects in one click.
  * CSV export: Download your resolved links for auditing or client handoff.
  * Progress & history: See scan status, last run (manual vs. automatic), and counts by category.
  * No noise: System/admin URLs (e.g., wp-login/wp-admin) are ignored.

**How it works**

* Scans the rendered content of posts, pages, and media items to extract internal links.
* Checks each destination and classifies the result (Permanent/Temporary Redirect, Broken).
* Applies your auto-resolve preference for 301/308; everything else is queued to review.
* Logs resolutions and lets you download them as CSV for records.

**Safe & fast by design**

* Uses Action Scheduler to process scans without timeouts on larger sites.
* Honors WordPress capabilities—only admins can run scans or change settings.
* All processing happens on your site; no data leaves your server.

**Perfect for**

* Site owners, editors, and SEO teams who want clean internal links, fewer 404s, and less manual cleanup after URL changes or migrations.

**Coming soon in Pro**

* External link checks (outbound URLs)
* Real-time checks on publish/update
* Image/PDF/media link checks
* Email summaries after scheduled scans
* Bulk actions (dismiss/unlink/re-check)
* Keyword<span aria-hidden="true" class="wp-exclude-emoji">→</span>URL auto-linking rules

== Installation ==

1. Upload the `link-sentinel` folder to the `/wp-content/plugins/` directory, or install via the WordPress Plugins screen.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Navigate to **Tools <span aria-hidden="true" class="wp-exclude-emoji">→</span> LinkSentinel** and click **Start Scan** to scan existing content. The plugin will also scan daily at 2:00 AM by default (configurable in **Settings**).

== Frequently Asked Questions ==

= Does this plugin scan external links? =
Not yet. The free version focuses on internal links within your site’s domain. Premium features will introduce external link scanning and more automation.

= What about images and media files? =
Currently only anchor (`<a>`) tags are scanned. Support for images (`<img>` tags) and other media is planned as part of the future roadmap.

= Can I disable the automatic daily scan? =
Yes. You can remove the scheduled event by deactivating the plugin or using a plugin like WP Crontrol to manage cron events.

== Screenshots ==

1. Dashboard — Scan & Schedule card with tabs for Resolved Links, Pending Redirects, Broken Links, and Settings.
2. Settings — choose daily scan time, enable auto-resolve for 301/308, and select post types to scan.
3. Pending Redirects — review detected redirects with HTTP code and “Resolve All” action.
4. Broken Links — table of 4xx results with inline “Change Link” action.
5. Resolved Links — corrected URLs with action taken, source post, date corrected, and CSV export/clear actions.
6. Broken Links (inline edit) — update the target URL directly in the table and submit.

== Changelog ==

= 1.8.7 – 2025-10-21 =
* Polished the code for production submission. Removed internal comments referencing developer documentation and ensured no references to internal tools remain.
* Cleaned up the plugin description by consolidating duplicate bullet points and clarifying that the dashboard provides tabs for resolved links, pending redirects, broken links, and settings.
* Updated version numbers and stable tag to 1.8.7.

= 1.8.6 – 2025-10-21 =
* Fixed: The dashboard now always returns to your previously selected tab after scans or auto-fixes. The interface no longer defaults to the Settings tab or an outdated anchor.
* Added: Auto-resolve can now be toggled in Settings; permanently redirected links (301/308) are only fixed automatically when enabled. Temporary redirects (302/307) and broken links remain pending for manual review.
* Added: Dynamic copyright notice shows the current year and links to Coquina Works.
* Added: Counts on the Pending Redirects and Broken Links tabs to display outstanding issues at a glance.
* Fixed: Resolution dates display a dash when no date exists instead of showing `0000-00-00 00:00:00`.
* Misc: Various UI tweaks, accessibility improvements, and code refactors for production readiness.

= 1.8.5 – 2025-10-21 =
* Added: Option in Settings to automatically resolve permanent redirects. With auto-resolve disabled, all 3xx responses go to the Pending Redirects tab first.
* Improved: Fixed links skip the pending table entirely when auto-resolve is on, while temporary redirects and broken links remain pending.
* Misc: Further refined date handling and cleaned up code to align with WordPress development standards.

= 1.8.4 – 2025-10-21 =
* Added: “Clear Table” link next to the CSV export button on the Resolved Links tab, allowing administrators to remove all resolved entries with a confirmation prompt.
* Added: Inline “Change Link” action in the Broken Links table for editing URLs directly in place, with support for relative slugs.
* Added: Bulk “Resolve All” button on the Pending Redirects tab to resolve every pending redirect at once.
* Fixed: Broken links only appear under the Broken Links tab; they are no longer duplicated in Pending Redirects.
* Misc: Initial implementation of counts on tabs and support for relative slugs in URL changes.

= 1.8 – 2025-10-21 =
* Added: Dashboard redesign with tabs for Resolved Links, Pending Redirects, Broken Links, and Settings. Includes progress indicators, a scan schedule card, and CSV export.
* Added: Auto-resolve setting for permanent redirects with sensible defaults. All redirects are sent to Pending first unless auto-resolve is enabled.
* Added: Settings page to choose scan time and post types. The nightly scan is scheduled according to these preferences.
* Improved: Upgraded scanning engine to avoid following all hops and skip admin/login paths. Duplicate issues are suppressed on subsequent scans.
* Misc: Numerous refactors, accessibility improvements, and preparation for future premium extensions.

= 1.7.x =
* Introduced the initial scanning engine, Action Scheduler integration, and multi-tab dashboard with Resolved, Pending, and Broken Links.
* Added CSV export, Clear Table, Resolve Now, and Resolve All actions for efficient management.
* Implemented inline Change Link editing with support for relative slugs and moved the action to its own column for clarity.
* Ensured only internal links are scanned and excluded WordPress admin/login URLs. Broken links (4xx/5xx) show only in the Broken Links tab.
* Consolidated resolved items into a single table and added basic progress feedback during scans.

= Previous releases =
Earlier releases laid the groundwork for LinkSentinel, establishing the core architecture, scanning logic, and user interface. These versions addressed packaging issues, mixed-content warnings, and the transition from the legacy Advanced Link Health Monitor. Refer to the source history for details on versions prior to the 1.7 series.

== Upgrade Notice ==

= 1.8.7 =
Polish and submission readiness. Cleaned description and removed internal comments; no functional changes. If you’re on 1.8.6, you’re already current on features.

= 1.8.6 =
Fixes tab persistence after scans/auto-fix and adds an option to auto-resolve 301/308. Recommended update for better UX and control.